// Fehlerbearbeitung und Serververbindung
document.addEventListener("DOMContentLoaded", function() {
  document.querySelector('.login-form').addEventListener('submit', function(event) {
    event.preventDefault();

    function validateAndDisplayError(inputElement) {
      if (!inputElement.value.trim()) {
        inputElement.classList.add("error");
        return false;
      } else {
        inputElement.classList.remove("error");
        return true;
      }
    }

    var vorname = document.getElementById("vorname");
    var name = document.getElementById("name");
    var username = document.getElementById("username"); // Achten Sie auf die Konsistenz der ID
    var password = document.getElementById("password"); // Achten Sie auf die Konsistenz der ID

    var isVornameValid = validateAndDisplayError(vorname);
    var isNameValid = validateAndDisplayError(name);
    var isUsernameValid = validateAndDisplayError(username);
    var isPasswordValid = validateAndDisplayError(password);

    if (isVornameValid && isNameValid && isUsernameValid && isPasswordValid) {
      // Daten an den Server senden
      fetch('/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `username=${encodeURIComponent(username.value)}&password=${encodeURIComponent(password.value)}`,
      })
      .then(response => response.text())
      .then(data => {
        alert(data);
        window.location.href = "informationsscreen.html"; // Weiterleitung, wenn die Serverantwort erfolgreich ist
      })
      .catch((error) => {
        console.error('Fehler:', error);
      });
    } else {
      alert("Bitte füllen Sie alle erforderlichen Felder aus.");
    }
  });
});

document.addEventListener('DOMContentLoaded', function () {
  // Validierungsfunktion für Benutzernamen und Passwort
  function validateInput(event) {
      const input = event.target;
      const validValue = input.value.replace(/[^a-zA-Z0-9]/g, '');
      if (input.value !== validValue) {
          input.value = validValue; 
          alert('Nur Buchstaben und Zahlen sind erlaubt.');
      }
  }

  // Event-Listener für die Eingabefelder
  const usernameInput = document.getElementById('username');
  const passwordInput = document.getElementById('password');

  usernameInput.addEventListener('input', validateInput);
  passwordInput.addEventListener('input', validateInput);
});

