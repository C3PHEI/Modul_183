const express = require('express');
const sql = require('mssql/msnodesqlv8');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

const config = {
    database: 'LoginGapsch',
    server: 'DESKTOP-2MEVUSI\\SQLEXPRESS01',
    driver: 'msnodesqlv8',
    options: {
        trustedConnection: true
    }
};

app.post('/login', async (req, res) => {
    try {
        await sql.connect(config);
        const { username, password } = req.body;
        const result = await sql.query`SELECT * FROM users WHERE Username = ${username} AND Password = ${password}`;
        
        if (result.recordset.length > 0) {
            res.send('Anmeldung erfolgreich');
        } else {
            res.send('Anmeldedaten sind falsch');
        }
    } catch (err) {
        console.error('Datenbankverbindung fehlgeschlagen', err);
        res.status(500).send('Serverfehler');
    }
});


const redis = require('redis');
const client = redis.createClient();

client.on('connect', function() {
    console.log('Connected to Redis...');
});


app.listen(port, () => {
    console.log(`Server läuft auf http://localhost:${port}`);
});